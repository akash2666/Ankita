package com.mph.hystricdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableEurekaClient
//@EnableHystrixDashboard
public class HystricDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(HystricDashboardApplication.class, args);
	}

}
