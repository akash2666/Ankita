package com.mph.hystricdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystricDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
