package com.mph.Detail.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mph.Detail.entity.Detail;

public interface DetailRepository extends JpaRepository<Detail,Long>{
	
	@Query( value ="select dId,Designation,ManagerName,ManagerId from Detail where empId=:empId")
	List<Object[]> findByempId(@Param("empId") int empId);

}
