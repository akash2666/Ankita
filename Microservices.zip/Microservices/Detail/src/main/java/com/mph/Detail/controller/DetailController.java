package com.mph.Detail.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mph.Detail.entity.Detail;
import com.mph.Detail.repo.DetailRepository;
import com.mph.Detail.service.DeatilService;

@RestController
@RequestMapping("detail")
public class DetailController {
	
	
	@Autowired
	DeatilService detailService;
	
	@GetMapping()
	public List<Detail> getAllDetail(){
		return detailService.getAllDetails();
	}
	
	@GetMapping("/employee/{empId}")
	public List<Object[]> getById(@PathVariable("empId") int empId){
		return detailService.getById(empId);
	}

}
