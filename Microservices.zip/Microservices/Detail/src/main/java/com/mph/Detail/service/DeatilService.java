package com.mph.Detail.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mph.Detail.entity.Detail;
import com.mph.Detail.repo.DetailRepository;

@Service
public class DeatilService {
	
	@Autowired
	DetailRepository detailRepository;
	
	
	public List<Detail> getAllDetails() {
		return detailRepository.findAll();
	}
	
	public List<Object[]> getById(int empId){
		return detailRepository.findByempId(empId);
	}
	
	

}
