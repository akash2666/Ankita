insert into DETAIL values(1,'Dev',213,'prashanth',1);
insert into DETAIL values(2,'test',200,'shrikant',2);
insert into DETAIL values(3,'production',300,'ramesh',3);
insert into DETAIL values(4,'Maintainance',400,'hausa',4);
SELECT * FROM DETAIL;
commit; 



insert into Employee values(1,'akash@gmail.com','akash',1);
insert into Employee values(2,'mahesh@gmail.com','mahesh',2);
insert into Employee values(3,'komal@gmail.com','komal',3);
insert into Employee values(4,'rushi@gmail.com','rushi',4);
SELECT * FROM Employee 
commit; 