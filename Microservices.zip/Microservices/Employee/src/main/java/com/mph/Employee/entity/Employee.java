package com.mph.Employee.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Employee {
	
	@Id
	private int empId;
	private String empName;
	private String empEmail;
	
//	@OneToOne
//	private Detail details;
	//@OneToMany(mappedBy = "dId", orphanRemoval = true)
	@OneToOne
	@JoinColumn(name="dId")
	private Detail  detail;
	

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public Employee(int empId, String empEmail, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
	}
	public Employee(int empId, String empName, String empEmail, Detail detail) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
		this.detail = detail;
	}



	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getEmpEmail() {
		return empEmail;
	}


	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}


	public Detail getDetail() {
		return detail;
	}


	public void setDetail(Detail details) {
		this.detail = details;
	}




	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empEmail=" + empEmail + ", detail=" + detail
				+ "]";
	}

	
}
