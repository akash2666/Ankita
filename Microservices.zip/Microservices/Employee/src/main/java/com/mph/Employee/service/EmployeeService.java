package com.mph.Employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mph.Employee.entity.Employee;
import com.mph.Employee.repo.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public Optional<Employee> getEmployee(int empId) {
		return  employeeRepository.findById(empId);
	}
	
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();
	}

}
