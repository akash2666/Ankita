package com.mph.Employee.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

@Entity
public class Detail {
	
	@Id
	private Long dId;
	
	private String Designation;
	private String ManagerName;
	private String ManagerId;
	
	
	private int empId;
	

	public Detail() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Detail(Long dId,  String designation, String managerName, String managerId, int empId) {
		super();
		this.dId = dId;
		
		Designation = designation;
		ManagerName = managerName;
		ManagerId = managerId;
		this.empId = empId;
	}


	public Long getdId() {
		return dId;
	}


	public void setdId(Long dId) {
		this.dId = dId;
	}



	public String getDesignation() {
		return Designation;
	}


	public void setDesignation(String designation) {
		Designation = designation;
	}


	public String getManagerName() {
		return ManagerName;
	}


	public void setManagerName(String managerName) {
		ManagerName = managerName;
	}


	public String getManagerId() {
		return ManagerId;
	}


	public void setManagerId(String managerId) {
		ManagerId = managerId;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	

}
