package com.mph.Employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mph.Employee.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>{

}
