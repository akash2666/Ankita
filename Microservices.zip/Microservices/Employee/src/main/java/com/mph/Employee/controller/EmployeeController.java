package com.mph.Employee.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mph.Employee.entity.Detail;
import com.mph.Employee.entity.Employee;
import com.mph.Employee.service.EmployeeService;


@RestController
@RequestMapping("employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping()
	public List<Employee> getAll() {
		return employeeService.getAllEmployee();
	}
	@GetMapping(value="/{empId}")
	public Optional<Employee> getEmployee(@PathVariable("empId") int empId) {
		Optional<Employee> employee =employeeService.getEmployee(empId);
		//Employee employee1=new Employee();
	    //http://localhost:9002/detail/employee/1
		List details= this.restTemplate.getForObject("http://localhost:9002/detail/employee/"+empId,List.class);
		
		System.out.println(details);
		
		
		
		
		
		//employee1.setDetail(JSONArray.toJSONString(details));
		return  employee;
	}

}
