package com.example.ApiGateway.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackController {


    @GetMapping("/employeeServiceFallback")
    public String employeeServiceFallback() {
    	
        return "Employee service is down at this time !!";
    }

    @GetMapping("/detailtServiceFallback")
    public String detailtServiceFallback() {
        return "Detail service is down at this time";
    }

}
