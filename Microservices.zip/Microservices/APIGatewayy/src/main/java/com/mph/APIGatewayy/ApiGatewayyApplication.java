package com.mph.APIGatewayy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@EnableEurekaClient
public class ApiGatewayyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayyApplication.class, args);
	}

}
